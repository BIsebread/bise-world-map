# 🍞 Bise — 世界のパンと料理の旅マップ

パン教室 Bise の「世界のパンと料理の旅マップ」アプリです。

---

## ファイル構成

```
bise-world-map/
├── index.html          ← メインの地図画面（生徒も見られる）
├── admin.html          ← 管理画面（先生だけが使う）
├── css/
│   └── style.css       ← デザイン設定
└── js/
    ├── firebase-config.js  ★ ここにFirebaseキーを貼り付ける
    └── db.js               ← データベース操作（変更不要）
```

---

## セットアップ手順

### ステップ1：Firebaseを設定する

1. [https://firebase.google.com](https://firebase.google.com) にログイン
2. 「プロジェクトを追加」→ 名前「bise-world-map」
3. 左メニュー「Firestore Database」→「データベースを作成」→「テストモード」
4. 左メニュー「Storage」→「始める」→「テストモード」
5. 「プロジェクトの設定」→「マイアプリ」→「</>」→ 設定コードをコピー
6. `js/firebase-config.js` を開いて、コピーした値を貼り付ける

### ステップ2：GitHubにアップロードする

1. [https://github.com](https://github.com) でアカウント作成
2. 「New repository」→ 名前「bise-world-map」→「Public」→ 作成
3. このフォルダのファイルをすべてアップロード（ドラッグ＆ドロップ）
4. 「Settings」→「Pages」→「Source: Deploy from a branch」→「Branch: main」→「Save」
5. 数分後に `https://あなたのユーザー名.github.io/bise-world-map/` でアクセス可能！

---

## 使い方

- **地図を見る**：`index.html` にアクセス → 国をクリックでレッスン詳細を表示
- **データを登録・編集**：`admin.html` にアクセス → 国を選んでレッスンを追加

---

## 初回起動時

Firebaseの設定が正しければ、`index.html` を開いたときに
「サンプルデータを登録しますか？」と聞かれます。
「OK」を押すと5カ国のサンプルデータが自動で登録されます。
